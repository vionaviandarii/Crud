<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3>Tutorial CRUD Laravel 5.3</h3>
			<div class="panel panel-default">
				<div class="panel-body">
					<form action="<?php echo e(route('crud.update', $cruds->id)); ?>" method="post">
					<input name="_method" type="hidden" value="PATCH">
					<?php echo e(csrf_field()); ?>

						<div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
							<input type="text" name="nama" class="form-control" placeholder="Nama" value="<?php echo e($cruds->nama); ?>">
							<?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
							<input type="text" name="alamat" class="form-control" placeholder="alamat" value="<?php echo e($cruds->alamat); ?>">
							<?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group<?php echo e($errors->has('tanggal_lahir') ? ' has-error' : ''); ?>">
							<input type="date" name="tanggal_lahir" class="form-control" placeholder="yyyy/mm/dd" value="<?php echo e($cruds->tanggal_lahir); ?>">
							<?php echo $errors->first('tanggal_lahir', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group<?php echo e($errors->has('tanggal_lahir') ? ' has-error' : ''); ?>">
							<select name="pekerjaan" id="pekerjaan" class="form-control" value="<?php echo e($cruds->pekerjaan); ?>">
								<option value="">Select One</option>
								<option value="pns">Pegawai Negeri Sipil</option>
								<option value="guru">Guru</option>
								<option value="mahasiswa">Mahasiswa</option>
								<option value="nelayan">Murid</option>
								<option value="dll">Lainnya</option>
							</select>
							<?php echo $errors->first('tanggal_lahir', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary" value="Simpan">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>